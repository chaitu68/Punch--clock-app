PUNCH CLOCK — VERSION 2

Features:
- Offline local storage
- First tap each day = Punch In
- Second tap = Punch Out
- Live clock
- Monthly history
- Total worked hours per day and month
- Edit attendance records
- Undo last punch
- Month-specific Excel (.xlsx) export
- iPhone Home Screen/PWA support

iPhone:
1. Put these files on a web host (or open index.html locally if your browser permits).
2. Open index.html in Safari.
3. Share -> Add to Home Screen.
4. Use the PUNCH button.

Data remains in browser local storage. Do not clear Safari website data or the records will be removed.
